package corejavaassignments;

import java.util.Scanner;

public class Program3_Sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
     System.out.print("Enter the Input1:\n");
     int a = sc.nextInt();
     System.out.print("Enter the Input2:\n");
     int b = sc.nextInt();
     System.out.println("Sum:\n"+a+"+"+b+"="+(a+b));
     System.out.println("Subtract:\n"+a+"+"+b+"="+(a+b));
     System.out.println("Multiply:\n"+a+"+"+b+"="+(a+b));
     System.out.println("Divide:\n"+a+"+"+b+"="+(a+b));
     System.out.println("Remainder:\n"+a+"+"+b+"="+(a%b));
	}

}
