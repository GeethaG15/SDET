package corejavaassignments;

public class Program1_Hello_Name {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     System.out.println("Hello\nGeethapriya");
		}

}
