package sdetassignment_task1;

import java.util.Arrays;
import java.util.Scanner;

public class GreatestNumber_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
GreatestNumber_Array prg=new GreatestNumber_Array();
int s,q;
System.out.print("Enter the number of elements in array");
s=sc.nextInt();
q=sc.nextInt();
System.out.print("Enter the elements in array:\n");
int a[]=new int[s];
int k[]=new int[q];
for(int i=0;i<s;i++)
{
	a[i]=sc.nextInt();
	}
System.out.print("Enter the query to be searched:\n");
for(int i=0;i<q;i++)
{
	k[i]=sc.nextInt();
}
System.out.print("The largest number smaller than queries:\n");
Arrays.sort(a);
for(int i=0;i<q;i++)
{
	System.out.println(prg.largenum(a,k[i]));
	}
sc.close();
	}
	private int largenum(int a[],int l)
{
	for(int i=0;i<a.length;i++)
	{
		if(a[i]>=l)
		{
						return a[i-1];
		}
	}
	return a[a.length-1];
}
	}

