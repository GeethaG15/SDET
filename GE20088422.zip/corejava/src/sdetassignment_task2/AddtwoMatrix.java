package sdetassignment_task2;

public class AddtwoMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a[][]= {{1,3,6},{4,5,7}};
int b[][]= {{4,2,1},{6,9,8}};
int c[][]=new int[2][3];
System.out.print("Sum of two matrices:\n");
for(int i=0;i<2;i++)
{
	for(int j=0;j<3;j++)
	{
		c[i][j]=a[i][j]+b[i][j];
		System.out.print(c[i][j]+" ");
	}
	System.out.println();
}
	}

}
