package sdetassignment_task2;

import java.util.Arrays;
import java.util.Scanner;

public class Regarsubset  {
	    static int[][] subset = new int[100][];
	    static int z = 0;
	    static void combinationUtil(int arr[], int n, int r, 
	                          int index, int data[], int i) 
	    { 
	        // Current combination is ready to be printed,  
	        // print it 
	        if (index == r) {
	            subset[z++] = new int[r];
	            for (int j = 0; j < r; j++)
	            subset[z-1][j] = data[j];
	            //    subset[z++] = data[j];
	                //System.out.print(data[j] + " "); 
	            //System.out.println("");
	            return; 
	        } 
	  
	        // When no more elements are there to put in data[] 
	        if (i >= n) 
	            return; 
	  
	        // current is included, put next at next 
	        // location 
	        data[index] = arr[i]; 
	        combinationUtil(arr, n, r, index + 1,  
	                               data, i + 1); 
	  
	        // current is excluded, replace it with 
	        // next (Note that i+1 is passed, but 
	        // index is not changed) 
	        combinationUtil(arr, n, r, index, data, i + 1); 
	    } 
	  
	    // The main function that prints all combinations 
	    // of size r in arr[] of size n. This function  
	    // mainly uses combinationUtil() 
	    static void printCombination(int arr[], int n, int r) 
	    { 
	        // A temporary array to store all combination 
	        // one by one 
	        int data[] = new int[r]; 
	  
	        // Print all combination using temprary 
	        // array 'data[]' 
	        combinationUtil(arr, n, r, 0, data, 0); 
	    } 
	    public static void main(String args[]){
	        @SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
	        int num_tests = sc.nextInt();
	        for(int i=0;i<num_tests;i++){
	            int num_of_array = sc.nextInt();
	            int[] array = new int[num_of_array];
	            int subset_size = sc.nextInt();
	            int num_of_popup_made = sc.nextInt()-1;
	            for(int index=0;index<num_of_array;index++){
	                array[index] = sc.nextInt();
	            }
	            printCombination(array, num_of_array, subset_size);
	            int[] sums = new int[z];
	            for(int index=0;index<sums.length;index++){
	                for(int internal_index=0;internal_index<subset_size;internal_index++){
	                    sums[index] +=subset[index][internal_index];
	                }
	            }
	            Arrays.sort(sums);
	            System.out.println("The solutions is: "+(sums[num_of_popup_made] - sums[0]));
	        }
	    }
	}