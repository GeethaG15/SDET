package sdetassignment_task3;

import java.util.Scanner;

public class Identitymatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner ob=new Scanner(System.in);
        System.out.println("Enter the Matrix order");
        int n=ob.nextInt();
        int mat[][]=new int[n][n];
        System.out.println("Enter elements of matrix in row by column order.");
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                mat[i][j]=ob.nextInt();
            }
        }
        System.out.println("The matrix entered is");
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                System.out.print(mat[i][j]);
            }
            System.out.println();
        }
        int flag=0;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                if((i==j&&mat[i][j]!=1) || (i!=j&&mat[i][j]!=0))
                {
                    flag=1;
                    break;
                }
            }
            if(flag==1)
                break;
        }
        if(flag==1)
            System.out.println("The matrix entered is not an Identity Matrix.");
        else
            System.out.println("The matrix entered is an Identity Matrix.");
    }
}
