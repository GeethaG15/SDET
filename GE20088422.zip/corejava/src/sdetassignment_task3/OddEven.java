package sdetassignment_task3;

public class OddEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				int rows, cols; 
				int  countEven=0,countOdd=0;
		        int a[][] = {{1, 2, 3},{8, 6, 4},{4, 5, 6}};  
		          rows = a.length;  
		          cols = a[0].length;  
		              for(int i = 0; i < rows; i++){  
		                  for(int j = 0; j < cols; j++){  
		                    if(a[i][j] % 2 == 0)  
		                      countEven++;
		                    else  
		                    	countOdd++; 
		                }  
		              }
		                System.out.println("Frequency of Odd numbers:"+countOdd);
		                System.out.println("Frequency of Odd numbers:"+countEven);
		            }  
		        }  
		 