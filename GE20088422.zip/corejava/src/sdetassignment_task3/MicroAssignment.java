package sdetassignment_task3;

public class MicroAssignment {

	static double mod(Double a, int m) 
    {
        return (a*(a+1)*(2*a+1)/6)%m;
    }
    public static void main(String[] args){
        int m = 1000000007;
        double a = 1.23;
        System.out.println("v: "+mod(a,m));
        a = 4.0;
        System.out.println("v: "+mod(a,m));
    }
}